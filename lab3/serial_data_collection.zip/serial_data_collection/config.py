prob = [2**i for i in range(2 , 11)]

## warning, don't remove 0, main.py doesn't rectify
procs = [0]
